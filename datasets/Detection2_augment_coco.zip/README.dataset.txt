# Detection2 > 2023-03-02 6:39pm
https://universe.roboflow.com/instance-segmentation/detection2-ippyb

Provided by a Roboflow user
License: CC BY 4.0

