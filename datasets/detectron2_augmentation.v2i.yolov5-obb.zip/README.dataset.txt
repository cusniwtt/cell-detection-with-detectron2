# detectron2_augmentation > 2023-02-27 6:24pm
https://universe.roboflow.com/detectron2-2awod/detectron2_augmentation

Provided by a Roboflow user
License: CC BY 4.0

