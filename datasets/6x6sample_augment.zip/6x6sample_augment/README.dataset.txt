# detectron2 > yolo2coco_with_augmentation
https://universe.roboflow.com/detectron2-2awod/detectron2-uzwhc

Provided by a Roboflow user
License: CC BY 4.0

